import React from 'react';

const Footer = () => {
    return (
        <footer className="footer">
        <span>All Rights Reserved 2023 © evision Software Solutions</span>
      </footer>
    );
};

export default Footer;