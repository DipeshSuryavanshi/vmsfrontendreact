// import axios from 'axios';

// const BASE_URL = 'http://localhost:8082';

// const ProfileService = {
//   registerCandidate: async (formData) => {
//     try {
//       const response = await axios.post(`${BASE_URL}/candidate/register`, formData);
//       return response.data;
//     } catch (error) {
//       throw new Error('Error registering candidate: ' + error.message);
//     }
//   },
//   // Add other methods for fetching, updating, or deleting candidate information
// };

// export default ProfileService;
